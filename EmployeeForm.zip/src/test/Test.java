package test;

public class Test {

	
	
	public static void main(String[] args) {
		String str="abc";
		System.out.println(str);
		str=str+"a";
		System.out.println(str);
	}
}
