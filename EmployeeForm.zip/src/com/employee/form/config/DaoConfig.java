package com.employee.form.config;

import javax.sql.DataSource;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.employee.form.dao.EmployeeDao;
import com.employee.form.dao.EmployeeDaoImpl;

public class DaoConfig {
	
	@Bean
	public DataSource dataSource(){
		DriverManagerDataSource driverManagerDataSource=new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
		driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/world");
		driverManagerDataSource.setUsername("root");
		driverManagerDataSource.setPassword("Annaraj1$");
		return driverManagerDataSource;
 	}

	@Autowired
	DataSource dataSource;
	
	@Bean
	public JdbcTemplate jdbcTemplate(){
		return new JdbcTemplate(dataSource);
	}
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
//@Bean
//public RestHighLevelClient restHighLevelClient(){
//	RestHighLevelClient restHighLevelClient= new RestHighLevelClient(
//			   RestClient.builder(
//	                    new HttpHost("localhost", 9200, "http"),
//	                    new HttpHost("localhost", 9201, "http")));
//	return restHighLevelClient;
//}
//	
//	
//	@Autowired
//	private RestHighLevelClient restHighLevelClient;	
	
	@Bean
	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return new NamedParameterJdbcTemplate(dataSource);
	}
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Bean
	public EmployeeDao employeeDao(){
		return new EmployeeDaoImpl(jdbcTemplate,namedParameterJdbcTemplate) ;
	}
	
	
}
