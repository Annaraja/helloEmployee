package com.employee.form.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.employee.form.dao.EmployeeDao;
import com.employee.form.service.EmployeeService;
import com.employee.form.service.EmployeeServiceImpl;
import com.employee.form.service.Exemployee;

public class ServiceConfig {

	@Autowired
	private EmployeeDao EmployeeDao;
	
	
	@Bean
	public EmployeeService employeeService(){
		return new EmployeeServiceImpl(EmployeeDao);
	}
	
	

}
