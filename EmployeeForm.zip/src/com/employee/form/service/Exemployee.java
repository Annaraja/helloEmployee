package com.employee.form.service;

import java.util.List;

import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;

import com.employee.form.dao.EmployeeDao;
import com.employee.form.entity.EmployeeEntity;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class Exemployee implements EmployeeService{

	
	private final  EmployeeDao employeeDao;
	
	@Override
	public List<EmployeeEntity> getAll() {
		System.out.println("exemployee");
		return employeeDao.getAll();
	}

	@Override
	public void insertEmployeeData(EmployeeEntity employeeEntity) {
		// TODO Auto-generated method stub
		
	}

}
