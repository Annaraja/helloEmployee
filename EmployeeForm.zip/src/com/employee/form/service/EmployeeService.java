package com.employee.form.service;

import java.util.List;

import com.employee.form.entity.EmployeeEntity;

public interface EmployeeService {

	List<EmployeeEntity> getAll();

	void insertEmployeeData(EmployeeEntity employeeEntity);

	void updateEmployeeDetail(EmployeeEntity employeeEntity);

	void deleteById(int id);

	EmployeeEntity getById(int id);

}
