package com.employee.form.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.RequiredArgsConstructor;

import org.apache.http.HttpHost;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.employee.form.entity.EmployeeEntity;
import com.employee.form.entity.UserMapper;

@Repository
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EmployeeDaoImpl implements EmployeeDao {

	private final JdbcTemplate jdbcTemplate;

	private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
//	private final RestHighLevelClient restHighLevelClient;

	@Override
	public List<EmployeeEntity> getAll() {
		String SQL = "SELECT * FROM employee";

		List<EmployeeEntity> empEntityList = namedParameterJdbcTemplate.query(
				SQL, new UserMapper());
		return empEntityList;
	}

	@Override
	public void insertEmployeeData(SqlParameterSource sqlParameterSource,
			EmployeeEntity employeeEntity) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String SQL = "INSERT INTO employee(EMPNAME,EMPNUM,EMPMAIL,EMPCITY,EMPAGE) "
				+ "VALUES ( :empname, :empnum, :empmail, :empcity, :empage)";
		namedParameterJdbcTemplate.update(SQL, sqlParameterSource, keyHolder);
		employeeEntity.setId(keyHolder.getKey().intValue());
//		@SuppressWarnings("resource")
//		RestHighLevelClient restHighLevelClient= new RestHighLevelClient(
//				   RestClient.builder(
//		                    new HttpHost("localhost", 9200, "http"),
//		                    new HttpHost("localhost", 9201, "http")));
//		 Map<String, Object> dataMap = new HashMap<String, Object>();
//		     dataMap.put("personId", "1002");
//		     dataMap.put("personName", "ajith");
//		IndexRequest indexRequest = new IndexRequest("training", "check", "1002").source(dataMap);
//		 try {
//			         IndexResponse response = restHighLevelClient.index(indexRequest);
//			     } catch(ElasticsearchException e) {
//			         e.getDetailedMessage();
//			     } catch (java.io.IOException ex){
//			         ex.getLocalizedMessage();
//			     }
	}

	@Override
	public void updateEmployeeDetails(EmployeeEntity employeeEntity) {
		// TODO Auto-generated method stub
	String sql= "UPDATE employee SET empname=?, empmail=?, empcity=?,empnum=? where empid=?";
	jdbcTemplate.update(sql,employeeEntity.getEmpname(),employeeEntity.getEmpmail(),employeeEntity.getEmpcity(), employeeEntity.getEmpnumber(),employeeEntity.getId());
	}

	@Override
	public void deleteById(int id) throws Exception {
		//String selectSql="SELECT * from employee where empid=?";
		//jdbcT
		String SQL="DELETE from employee where empid=?";
 int status=jdbcTemplate.update(SQL, id);
		if(status==0){
			throw new NullPointerException();
		}
	}

	@Override
	public EmployeeEntity getById(int id) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", id);
		try{
		String SQL="SELECT * from employee where empid=:id";
		EmployeeEntity employeeEntity=namedParameterJdbcTemplate.queryForObject(SQL, params, new UserMapper());
		return employeeEntity;
		}catch(Exception ex){
			return new EmployeeEntity();
		}

	}

}
