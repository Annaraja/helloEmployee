package com.employee.form.dao;

import java.util.List;

import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.employee.form.entity.EmployeeEntity;

public interface EmployeeDao {

	List<EmployeeEntity> getAll();

	void insertEmployeeData(SqlParameterSource sqlParameterSource, EmployeeEntity employeeEntity);

	void updateEmployeeDetails(EmployeeEntity employeeEntity);

	void deleteById(int id) throws Exception;

	EmployeeEntity getById(int id);

}
