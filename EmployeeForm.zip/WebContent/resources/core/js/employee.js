var ageInput=document.getElementById("age_input");


ageInput.DOMfocusout=function(){
	alert();
}