import { Subscription } from 'rxjs';
import { ShoppingListService } from './../shopping-list.service';
import { Ingredient } from './../../shared/ingredients.model';
import { Component, OnInit, Input, Output,EventEmitter, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit {

//@Output()
//addIngredient=new EventEmitter<{ingredient:Ingredient}>();
editedSubscription:Subscription;
editedIndex:number;
editMode:boolean;
@ViewChild('f') ngForm:NgForm;
  constructor(private shoppingListService :ShoppingListService) { }


  ngOnInit() {
  this.editedSubscription=  this.shoppingListService.editedStarted.subscribe(
(index:number)=>{
this.editedIndex=index;
this.editMode=true;
const ingredient=this.shoppingListService.getIngredient(index);
this.ngForm.setValue({
  'nameInput':ingredient.name,
  'amountInput':ingredient.amount
});
}

  );
  }
  
  clearInputs(){
   this.ngForm.reset();
   this.editMode=false;
  }

  deleteItem(){
    this.shoppingListService.deleteIngredient(this.editedIndex);
    this.clearInputs();
  }
  onSubmit(form:NgForm){
    let ingredient=new Ingredient(form.value['nameInput'],form.value['amountInput']);
    if(this.editMode)
      this.shoppingListService.updateIngredient(this.editedIndex,ingredient);
    else
    this.shoppingListService.addIngredient(ingredient);
    form.reset();
this.editMode=false;
  }
}
