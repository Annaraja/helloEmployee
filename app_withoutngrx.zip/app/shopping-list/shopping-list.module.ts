import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { ShoppingListComponent } from "./shopping-list.component";
import { ShoppingEditComponent } from "./shopping-edit/shopping-edit.component";
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';



const route:Routes=[
    {
         path: '', component: ShoppingListComponent 
    }
]


@NgModule({
 declarations:[
    ShoppingListComponent,
    ShoppingEditComponent
 ],
imports:[
    FormsModule,RouterModule.forChild(route),SharedModule
],

   exports:[
    ShoppingListComponent,
    ShoppingEditComponent
   ] 

})

export class ShoppingListModule{

}