import { EventEmitter } from '@angular/core';
import { Ingredient } from './../shared/ingredients.model';
import { Subject } from 'rxjs';

export class ShoppingListService{
    
private    ingredients=[
        new Ingredient("Apple",5),
        new Ingredient("Orange",12)
          ];

          editedStarted=new Subject<Number>();
ingredientChanged=new Subject<Ingredient[]>();
getAllIngredients(){
    return this.ingredients.slice();
}

addIngredient(ingredient:Ingredient){
this.ingredients.push(ingredient);
//this.ingredientChanged.emit(this.ingredients.slice());
this.ingredientChanged.next(this.ingredients.slice());
}

addToList(ingredients:Ingredient[]){
    this.ingredients.push(...ingredients);
  //  this.ingredientChanged.emit(this.ingredients.slice());
  this.ingredientChanged.next(this.ingredients.slice());
}
getIngredient(index:number){
 return this.ingredients[index];
}

updateIngredient(index:number,ing:Ingredient){
this.ingredients[index]=ing;
this.ingredientChanged.next(this.ingredients.slice());
}

deleteIngredient(index:number){
  this.ingredients.splice(index,1);
  this.ingredientChanged.next(this.ingredients.slice());
}

}