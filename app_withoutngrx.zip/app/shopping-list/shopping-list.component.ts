import { Ingredient } from './../shared/ingredients.model';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ShoppingListService } from './shopping-list.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit,OnDestroy {
  ngOnDestroy(): void {
   this.ingredientChangedSubscription.unsubscribe();
  }

  ingredients=[];
  ingredientChangedSubscription:Subscription;

  constructor(private shoppingListService: ShoppingListService) { }

  ngOnInit() {
    this.ingredients=this.shoppingListService.getAllIngredients();
   this.ingredientChangedSubscription= this.shoppingListService.ingredientChanged.subscribe(
      (ingredients)=> this.ingredients=ingredients
    );
  }
  addNewlyCreatedIngredients(ingredient:Ingredient){
    this.ingredients.push(ingredient['ingredient']);
  }

  editItem(index:number){
    this.shoppingListService.editedStarted.next(index);
  }
}
