import { Directive, ElementRef, HostListener, HostBinding } from "@angular/core";

@Directive({
    selector:'[appDropDown]'
})




export class DropDownDirective{

    @HostBinding('class.open') isOpen:boolean;

    constructor(private elementRef:ElementRef){

    }
/*
@HostListener('click') toggleDropDown(){
   // native js approach  this.elementRef.nativeElement.classList.toggle('open');
   this.isOpen=!this.isOpen;
}*/

 @HostListener('document:click', ['$event']) toggleOpen(event: Event) {
    this.isOpen = this.elementRef.nativeElement.contains(event.target) ? !this.isOpen : false;
  }

}