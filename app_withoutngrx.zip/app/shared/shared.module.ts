import { CommonModule } from '@angular/common';
import { NgModule } from "@angular/core";
import { AlertComponent } from "./alert/alert.component";
import { DropDownDirective } from "./dropdown.directive";
import { PlaceHolderDirective } from "./placeholder/placeholder.directive";
import { LoadingComponent } from "./loading/loading.component";
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
declarations:[
    DropDownDirective,
    PlaceHolderDirective,
    LoadingComponent,
    AlertComponent
],
imports:[
    CommonModule
],    
exports:[
    DropDownDirective,
    PlaceHolderDirective,
    LoadingComponent,
    AlertComponent,
    CommonModule
],
entryComponents:[AlertComponent]

})

export class SharedModule{

}