import { Ingredient } from './../../shared/ingredients.model';
import { ReceipesService } from './../receipes.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { Receipe } from '../receipe.models';

@Component({
  selector: 'app-receipe-edit',
  templateUrl: './receipe-edit.component.html',
  styleUrls: ['./receipe-edit.component.css']
})
export class ReceipeEditComponent implements OnInit {
  id: number;
  editMode: boolean;
  receipeEditForm:FormGroup;
  constructor(private activatedRoute: ActivatedRoute,private receipesService: ReceipesService,private router:Router) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(
      (params: Params) => {
        this.id = +params['id'];
        this.editMode = params['id'] != null;
        console.log(this.id, this.editMode);
        this.initForm();
      }
    )
  }

private initForm(){
let name='';
let imageUrl='';
let description='';
let ingredients=new FormArray([]);

if(this.editMode){
 const receipe= this.receipesService.getReceipeById(this.id);
 name=receipe.title;
imageUrl=receipe.imagePath;
description=receipe.description;
if(receipe['ingredients']){
for(let ingredient of receipe.ingredients){
  ingredients.push(
    new FormGroup({
      'name':new FormControl(ingredient.name,Validators.required),
      'amount':new FormControl(ingredient.amount,[Validators.required,Validators.pattern(/^[1-9]+[0-9]*$/)])
    })
  );
}
}
}

this.receipeEditForm =new FormGroup({
  'name':new FormControl(name,Validators.required),
  'imageUrl':new FormControl(imageUrl,Validators.required),
  'description':new FormControl(description,Validators.required),
  'ingredients':ingredients
})
}
addIngredient(){
 let ingredients= <FormArray>this.receipeEditForm.get('ingredients');
 ingredients.push(
   new FormGroup({
    'name':new FormControl(null,Validators.required),
    'amount':new FormControl(null,[Validators.required,Validators.pattern(/^[1-9]+[0-9]*$/)])
   })
 )
}
get controls() {
  return (this.receipeEditForm.get('ingredients') as FormArray).controls;
}
onSubmit(){
  let currentId;
if(this.editMode)
currentId=this.id;
else{
  const receipes=this.receipesService.getReceipes();
  currentId=receipes[receipes.length-1]['id']+1;
}
  const receipe=new Receipe(
    this.receipeEditForm.value['name'],
    this.receipeEditForm.value['description'],
    this.receipeEditForm.value['imageUrl'],
    this.receipeEditForm.value['ingredients'],
    currentId
  );
  if(this.editMode){
    console.log(receipe);
this.receipesService.updateReceipe(this.id,receipe);
  }else{
    console.log(receipe);
this.receipesService.addReceipe(receipe);
  }
  this.router.navigate(['../'],{relativeTo:this.activatedRoute});
}

removeIngredients(index:number){
(<FormArray>this.receipeEditForm.get('ingredients')).removeAt(index);
}

cancelEdit(){
  this.router.navigate(['../'],{relativeTo:this.activatedRoute});
}
}
