import { Component, OnInit,Input } from '@angular/core';
import { Receipe } from '../../receipe.models';

@Component({
  selector: 'app-receipe-list-item',
  templateUrl: './receipe-list-item.component.html',
  styleUrls: ['./receipe-list-item.component.css']
})
export class ReceipeListItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

  @Input()
  receipe:Receipe;

  @Input()
  index:number;




}
