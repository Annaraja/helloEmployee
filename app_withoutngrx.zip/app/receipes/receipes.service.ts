import { ShoppingListService } from './../shopping-list/shopping-list.service';
import { EventEmitter, Injectable } from "@angular/core";
import { Receipe } from "./receipe.models";
import { Ingredient } from "../shared/ingredients.model";
import { Subject } from 'rxjs';


@Injectable()
export class ReceipesService{
 private receipes: Receipe[]=[];
 /*
 private receipes: Receipe[]=[
   new Receipe(
     'Tasty Schnitzel',
     'A super-tasty Schnitzel - just awesome!',
     'https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG',
     [
       new Ingredient('Meat', 1),
       new Ingredient('French Fries', 20)
     ],0),
   new Receipe('Big Fat Burger',
     'What else you need to say?',
     'https://upload.wikimedia.org/wikipedia/commons/b/be/Burger_King_Angus_Bacon_%26_Cheese_Steak_Burger.jpg',
     [
       new Ingredient('Buns', 2),
       new Ingredient('Meat', 1)
     ],1)
   ];
*/
receipesChanged=new Subject<Receipe[]>();


getReceipes(){
  return this.receipes.slice();
}

constructor(private shoppingListService: ShoppingListService){

}


addItemToList(ingredients:Ingredient[]){
this.shoppingListService.addToList(ingredients);
}

getReceipeById(index){
 return this.receipes[index];
}


addReceipe(receipe:Receipe){
this.receipes.push(receipe);
this.receipesChanged.next(this.receipes.slice());
}

updateReceipe(index:number, receipe:Receipe){
this.receipes[index]=receipe;
this.receipesChanged.next(this.receipes.slice());
}
deleteReceipe(index:number){
this.receipes.splice(index,1);
this.receipesChanged.next(this.receipes.slice());
}
setReceipes(receipes:Receipe[]){
this.receipes=receipes;
this.receipesChanged.next(this.receipes.slice());
}
}