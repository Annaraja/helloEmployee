import { DataStorageService } from './../shared/data-storage.service';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { Receipe } from "./receipe.models";
import { Observable } from "rxjs";
import { Injectable } from "@angular/core";
import { ReceipesService } from "./receipes.service";


@Injectable({providedIn:'root'})
export class ReceipesResolverService implements Resolve<Receipe[]>{
    constructor(private receipeService:ReceipesService,private dsservice:DataStorageService){}

    resolve(route: ActivatedRouteSnapshot, state:RouterStateSnapshot): Receipe[] | Observable<Receipe[]> | Promise<Receipe[]> {

 const receipes=this.receipeService.getReceipes();
 if(receipes.length<1)
       return this.dsservice.fetchReceipes();
       else
       receipes;
    }

}