import { NgModule } from "@angular/core";
import { ShoppingListService } from "./shopping-list/shopping-list.service";
import { ReceipesService } from "./receipes/receipes.service";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { AuthInterceptors } from "./auth/auth-interceptors.service";


@NgModule({
    providers: [ShoppingListService,ReceipesService,
        {
          provide:HTTP_INTERCEPTORS,useClass:AuthInterceptors,multi:true
        }],
})
export class CoreModule{

}