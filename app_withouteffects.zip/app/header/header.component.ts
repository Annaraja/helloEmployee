import { map } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { AuthService } from './../auth/auth.service';
import { DataStorageService } from './../shared/data-storage.service';
import { Component, Output, EventEmitter, OnInit, OnDestroy } from "@angular/core";
import { Subscription } from 'rxjs';
import * as fromGlobalState from '../store/app.reducers';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit,OnDestroy{

    ngOnDestroy(): void {
        this.authSubcription.unsubscribe();
    }
    ngOnInit(): void {
        this.authService.autologin();
        this.authSubcription=
   //     this.authService.outhToken.
   this.store.select('auth').pipe(map((outhToken)=>outhToken.auth)).
        subscribe(
            (token)=>{
                this.authenticated=!!token;
            }
        )
    }
    authenticated:boolean;
    authSubcription:Subscription;
    constructor(private dataStorageService: DataStorageService,private authService: AuthService,
        private store:Store<fromGlobalState.AppState>) {

    }
    @Output()
    selectedFeature = new EventEmitter<{ feature: string }>();

    selectFeature(feature: string) {
        this.selectedFeature.emit({ feature });
    }

    saveData() {
        this.dataStorageService.storeReceipe();
    }

    fetchReceipes(){
        this.dataStorageService.fetchReceipes().subscribe();
    }

    onLogOut(){
        this.authService.logOut();
    }
}