import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from  '@angular/common/http';

import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './header/header.component';
import { CoreModule } from './core.module';
import { StoreModule } from '@ngrx/store';
import * as fromAppReducers from './store/app.reducers'
import { ShoppingListReducers } from './shopping-list/store/shopping-list.reducers';
import { AuthReducers } from './auth/store/auth.reducers';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    StoreModule.forRoot({
      shoppingList:ShoppingListReducers,
      auth:AuthReducers
  }),
    HttpClientModule,
    SharedModule,
    CoreModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
