import { RouterModule, Routes } from '@angular/router';
import { NgModule } from "@angular/core";
import { ReceipesComponent } from "./receipes.component";
import { AuthGuard } from "../auth/auth-guard.service";
import { ReceipesStartComponent } from "./receipes-start/receipes-start.component";
import { ReceipeEditComponent } from "./receipe-edit/receipe-edit.component";
import { ReceipeDetailComponent } from "./receipe-detail/receipe-detail.component";
import { ReceipesResolverService } from "./receipes-resolver.service";


const routes:Routes= [{
    path: '', component: ReceipesComponent, 
    canActivate:[AuthGuard],
    children: [
        { path: '', component: ReceipesStartComponent },
        { path: 'new', component: ReceipeEditComponent },
        { path: ':id', component: ReceipeDetailComponent,resolve:[ReceipesResolverService] },
        { path: ':id/edit', component: ReceipeEditComponent ,resolve:[ReceipesResolverService]},
    ]
}];


@NgModule({
imports:[
    RouterModule.forChild(routes)
],
exports:[
    RouterModule
]
})
export class ReceipesRoutingModule{

}