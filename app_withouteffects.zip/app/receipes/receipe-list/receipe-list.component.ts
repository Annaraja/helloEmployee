import { Subscription } from 'rxjs';
import { Receipe } from './../receipe.models';
import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { ReceipesService } from '../receipes.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-receipe-list',
  templateUrl: './receipe-list.component.html',
  styleUrls: ['./receipe-list.component.css']
})
export class ReceipeListComponent implements OnInit,OnDestroy {
  receipes: Receipe[]=[];
  receipeSubscription:Subscription;
  constructor(private receipeService:ReceipesService,private router:Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.receipes=this.receipeService.getReceipes();
    console.log("All receipes in receipe list component ",this.receipes);
   this.receipeSubscription= this.receipeService.receipesChanged.subscribe(
      (receipes:Receipe[])=>{
        this.receipes=receipes;
      }
    )
  }
  newReceipe(){
this.router.navigate(['new',],{relativeTo:this.activatedRoute});
  }

  ngOnDestroy(): void {
    this.receipeSubscription.unsubscribe();
  }


}
