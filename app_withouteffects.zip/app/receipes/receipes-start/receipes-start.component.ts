import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receipes-start',
  templateUrl: './receipes-start.component.html',
  styleUrls: ['./receipes-start.component.css']
})
export class ReceipesStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
