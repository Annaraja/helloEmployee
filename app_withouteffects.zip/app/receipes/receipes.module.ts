import { SharedModule } from './../shared/shared.module';
import { NgModule } from "@angular/core";
import { ReceipesComponent } from './receipes.component';
import { ReceipeListComponent } from './receipe-list/receipe-list.component';
import { ReceipeDetailComponent } from './receipe-detail/receipe-detail.component';
import { ReceipeListItemComponent } from './receipe-list/receipe-list-item/receipe-list-item.component';
import { ReceipesStartComponent } from './receipes-start/receipes-start.component';
import { ReceipeEditComponent } from './receipe-edit/receipe-edit.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ReceipesRoutingModule } from './receipes-routing.modules';
import { RouterModule } from '@angular/router';

@NgModule({
declarations:[
    ReceipesComponent,
    ReceipeListComponent,
    ReceipeDetailComponent,
    ReceipeListItemComponent,
    ReceipesStartComponent,
    ReceipeEditComponent
],
imports:[
ReceipesRoutingModule,ReactiveFormsModule,SharedModule,RouterModule
],
exports:[
    ReceipesComponent,
    ReceipeListComponent,
    ReceipeDetailComponent,
    ReceipeListItemComponent,
    ReceipesStartComponent,
    ReceipeEditComponent
]
})
export class ReceipeModules{

}