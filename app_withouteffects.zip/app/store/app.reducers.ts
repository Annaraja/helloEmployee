import * as fromShoppingListReducers from '../shopping-list/store/shopping-list.reducers';
import * as fromAuthReducers from '../auth/store/auth.reducers'
import { ActionReducerMap } from '@ngrx/store';


export interface AppState{
    shoppingList:fromShoppingListReducers.State,
    auth:fromAuthReducers.state
}


//  export const appReducers:ActionReducerMap<AppState>={
//      shoppingList:fromShoppingListReducers.ShoppingListReducers,
//      auth:fromAuthReducers.AuthReducers
//  }