import { SharedModule } from './../shared/shared.module';
import { NgModule } from "@angular/core";
import { AuthComponent } from "./auth/auth.component";
import { Routes, RouterModule } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';



const route:Routes=[
    { path: '', component: AuthComponent }
]


@NgModule({
    declarations:[ AuthComponent],
    imports:[RouterModule.forChild(route),SharedModule,ReactiveFormsModule],
    exports:[RouterModule]
})

export class AuthModule{

}