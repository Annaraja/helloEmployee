import { Action } from '@ngrx/store';
import { OAuth2Token } from '../auth/oauth-token.model';
export const LOGIN='[auth] login';
export const LOGOUT='[auth] logout';

export class login implements Action{
    readonly type:string=LOGIN;
constructor(public payload:OAuth2Token){}
}

export class logout implements Action{
    readonly type:string=LOGOUT;
    payload:OAuth2Token=null;
}

export type authActions=login|logout;