import { OAuth2Token } from "../auth/oauth-token.model";
import * as AuthActions from './auth.actions';

export interface state{
    auth:OAuth2Token;
}


const initialState:state={
    auth:null
}

export function AuthReducers(state=initialState,action:AuthActions.authActions){
   switch(action.type){
case AuthActions.LOGIN:
    const oauthToken=action.payload;
return {
    ...state,
    auth: oauthToken
}

case AuthActions.LOGOUT:
return{
    ...state,
    auth:null
}
    default:
    return state;
   }


}