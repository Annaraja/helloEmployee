import { Store } from '@ngrx/store';
import { AuthService } from './auth.service';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { Injectable } from "@angular/core";
import { take, map, tap } from 'rxjs/operators';
import * as fromGlobalState from '../store/app.reducers';



@Injectable({providedIn:'root'})
export class AuthGuard implements CanActivate{

constructor(private authService:AuthService,private router:Router,private store:Store<fromGlobalState.AppState>){}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
     return this.store.select('auth').
    // return this.authService.outhToken.
     pipe(take(1),
     map((outhToken)=>outhToken.auth),
     map(
   (auth)=>  !!auth
     ),tap((outh)=>{
         if(!outh)
        return this.router.navigate(['/auth']);
     }));
       
    }

}