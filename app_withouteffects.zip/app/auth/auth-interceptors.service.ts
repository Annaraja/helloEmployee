import { Store } from '@ngrx/store';
import { AuthService } from './auth.service';
import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler } from "@angular/common/http";
import { take, exhaust, exhaustMap,map } from 'rxjs/operators';
import * as fromAppGlobal from '../store/app.reducers';


@Injectable({providedIn:'root'})
export class AuthInterceptors implements HttpInterceptor{

    constructor(private authService: AuthService,private store:Store<fromAppGlobal.AppState>){}
    intercept(req:HttpRequest<any>, next: HttpHandler) {   
        return   this.store.select('auth').pipe(   
    //   return  this.authService.outhToken.pipe( 
            take(1),
            map((outhToken)=>outhToken.auth),
             exhaustMap((oauth)=>{
  if(!oauth) return next.handle(req);
                 const accessToken=oauth['access_token'];
                 const modifiedReq=req.clone({headers:req.headers.append('Authorization','bearer'+" "+accessToken)})
                 return next.handle(modifiedReq);
             })
        )
    
    }

}