import { Store } from '@ngrx/store';
import { AuthService } from './../auth/auth.service';
import { ReceipesService } from './../receipes/receipes.service';
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Receipe } from '../receipes/receipe.models';
import {tap, exhaustMap, take,map} from 'rxjs/operators';
import { OAuth2Token } from '../auth/auth/oauth-token.model';
import * as fromGlobalApp from '../store/app.reducers';

@Injectable({providedIn:'root'})
export class DataStorageService{
constructor(private httpClient:HttpClient,private recipeService: ReceipesService,
    private authService:AuthService,private store:Store<fromGlobalApp.AppState>){}

storeReceipe(){
const receipes=this.recipeService.getReceipes();
this.httpClient.put("/receipeBook/updateAllReceipes",receipes).subscribe(
    (response)=>console.log(response)
)
}
fetchReceipes(){
    return this.store.select('auth')
 //  return this.authService.outhToken
   .pipe(
       take(1),
       map((outhToken)=>outhToken.auth),
       exhaustMap((oauthToken:OAuth2Token)=>{
        return this.httpClient.get<Receipe[]>("/receipeBook/fetchAll");
       }),
       tap(
        (response)=>this.recipeService.setReceipes(response)
    )
   )
}

}