import { AppModule } from './../app.module';
export class Ingredient{
    constructor(public name:string, public amount:number){

    }
}