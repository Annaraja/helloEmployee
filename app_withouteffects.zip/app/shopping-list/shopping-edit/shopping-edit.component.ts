import { Subscription } from 'rxjs';
import { Ingredient } from './../../shared/ingredients.model';
import { Component, OnInit, Input, Output,EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Store } from '@ngrx/store';
import * as ShoppingListAction from '../store/shopping-list.actions';
import * as fromAppReducers from './../../store/app.reducers';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit,OnDestroy {
  ngOnDestroy(): void {
    this.store.dispatch(new ShoppingListAction.StopEditing());
    this.editedSubscription.unsubscribe();
  }

//@Output()
//addIngredient=new EventEmitter<{ingredient:Ingredient}>();
editedSubscription:Subscription;
editedIndex:number;
editMode:boolean;
@ViewChild('f') ngForm:NgForm;
  constructor(private store:Store<fromAppReducers.AppState>) { }


  ngOnInit() {

    this.editedSubscription=   this.store.select('shoppingList').subscribe(
      (editedDatas)=>{
        if(editedDatas.editedIngredientIndex>-1){
this.editMode=true;
let ingredient=editedDatas.editedIngredient;
this.ngForm.setValue({
  'nameInput':ingredient.name,
  'amountInput':ingredient.amount
});
        }else{
this.editMode=false;
        }
      }
    )
    /*
  this.editedSubscription=  this.shoppingListService.editedStarted.subscribe(
(index:number)=>{
this.editedIndex=index;
this.editMode=true;
const ingredient=this.shoppingListService.getIngredient(index);
this.ngForm.setValue({
  'nameInput':ingredient.name,
  'amountInput':ingredient.amount
});
}

  );
  */
  }
  
  clearInputs(){
   this.ngForm.reset();
   this.editMode=false;
   this.store.dispatch(new ShoppingListAction.StopEditing());
  }

  deleteItem(){
   // this.shoppingListService.deleteIngredient(this.editedIndex);
   this.store.dispatch(new ShoppingListAction.DeleteIngredient());
    this.clearInputs();
  }
  onSubmit(form:NgForm){
    let ingredient=new Ingredient(form.value['nameInput'],form.value['amountInput']);
    if(this.editMode)
  //    this.shoppingListService.updateIngredient(this.editedIndex,ingredient);
  this.store.dispatch(new ShoppingListAction.UpdateIngredient(
    {ingredient}
    ));
    else
   // this.shoppingListService.addIngredient(ingredient);
   this.store.dispatch(new ShoppingListAction.AddIngredient(ingredient));
    form.reset();
this.editMode=false;
  }
}
