import { Ingredient } from './../shared/ingredients.model';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import * as fromAppReducers from './../store/app.reducers'
import * as fromShoppingListActions from './store/shopping-list.actions';



@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit {
  // ngOnDestroy(): void {
  //  this.ingredientChangedSubscription.unsubscribe();
  // }

  ingredients:Observable< {ingredients:Ingredient[]}>;
  //ingredientChangedSubscription:Subscription;

  constructor(private store:Store<fromAppReducers.AppState>) { }

  ngOnInit() {
    this.ingredients=this.store.select('shoppingList');
  //   this.ingredients=this.shoppingListService.getAllIngredients();
  //  this.ingredientChangedSubscription= this.shoppingListService.ingredientChanged.subscribe(
  //     (ingredients)=> this.ingredients=ingredients
  //   );
  }
  addNewlyCreatedIngredients(ingredient:Ingredient){
  //  this.ingredients.push(ingredient['ingredient']);
  }

  editItem(index:number){
  //  this.shoppingListService.editedStarted.next(index);
  this.store.dispatch(new fromShoppingListActions.StartEditing(index));
  }
}
