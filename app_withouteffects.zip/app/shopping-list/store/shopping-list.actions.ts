import { Action } from '@ngrx/store';
import { Ingredient } from 'src/app/shared/ingredients.model';
export const ADD_INGREDIENT= '[ShoppingList] ADD_INGREDIENT';
export const ADD_INGREDIENTS= '[ShoppingList] ADD_INGREDIENTS';
export const UPDATE_INGREDIENT= '[ShoppingList] UPDATE_INGREDIENT';
export const DELETE_INGREDIENT='[ShoppingList] DELETE_INGREDIENT';
export const START_EDITING='[ShoppingList] START_EDITING';
export const STOP_EDITING='[ShoppingList] STOP_EDITING';


export class AddIngredient implements Action{
  readonly  type: string=ADD_INGREDIENT;
  constructor(public payload:Ingredient){

  }
    
}

export class UpdateIngredient implements Action{
  readonly type:string =UPDATE_INGREDIENT;
   constructor(public payload:{
  //   index:number,
  ingredient:Ingredient
   }){}
}

export class DeleteIngredient implements Action{
  readonly type:string =DELETE_INGREDIENT;
   constructor(public payload?:number){

   }
}


export class AddIngredients implements Action{
 readonly type: string=ADD_INGREDIENTS;
 constructor(public payload:Ingredient[]){
 }
  
}

export class StartEditing implements Action {
  readonly type:string=START_EDITING;
  constructor(public payload:number){}
}


export class StopEditing implements Action{
  readonly type:string=STOP_EDITING;
  constructor(public payload?:number){}
}


export type ShoppingListActions= AddIngredient| AddIngredients | UpdateIngredient | DeleteIngredient | StartEditing |StopEditing;

