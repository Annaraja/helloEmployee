import * as ShoppingListAction from './shopping-list.actions';
import { Ingredient } from 'src/app/shared/ingredients.model';



export interface State{
    ingredients:Ingredient[],
    editedIngredient:Ingredient,
    editedIngredientIndex:number
}


const initialState:State={
    ingredients:[
        new Ingredient("Apple",5),
        new Ingredient("Orange",12)
          ],
          editedIngredient:null,
          editedIngredientIndex:-1
};

export function ShoppingListReducers(state=initialState,action:ShoppingListAction.ShoppingListActions){
    switch(action.type){
        case  ShoppingListAction.ADD_INGREDIENT:
        return {
            ...state,
            ingredients:[
                ...state.ingredients, action.payload
            ]
        };
        case ShoppingListAction.ADD_INGREDIENTS:
            return {
                ...state,
            ingredients:[ ...state.ingredients, ...action.payload]};

case ShoppingListAction.UPDATE_INGREDIENT:
 const alreadyPresentIngredient= state.ingredients;
 alreadyPresentIngredient[state.editedIngredientIndex]=action.payload['ingredient'];
         return {
             ...state,
             ingredients:[
                 ...alreadyPresentIngredient
             ]
         };
case ShoppingListAction.DELETE_INGREDIENT:
    return{
        ...state,
        ingredients:[
            ...state.ingredients.filter((ing,index)=>  index != state.editedIngredientIndex)
        ]
    }

case ShoppingListAction.START_EDITING:
   if(typeof(action.payload)==='number'){
    return {
        ...state,
        editedIngredientIndex:action.payload,
        editedIngredient:{...state.ingredients[action.payload]}
    } 
   }else{
       break;
   }       
case ShoppingListAction.STOP_EDITING:
    return {
        ...state,
        editedIngredient:null,
        editedIngredientIndex:-1
    }

        default:
            return state;
    }

    
}