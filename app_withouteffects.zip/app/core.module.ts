import { NgModule } from "@angular/core";
import { ReceipesService } from "./receipes/receipes.service";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { AuthInterceptors } from "./auth/auth-interceptors.service";


@NgModule({
    providers: [ReceipesService,
        {
          provide:HTTP_INTERCEPTORS,useClass:AuthInterceptors,multi:true
        }],
})
export class CoreModule{

}